export interface marker {
    lat: any;
    lng: any;
    id?: any;
    label?: string;
    draggable?: boolean;
  }
  