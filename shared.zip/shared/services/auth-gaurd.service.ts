import { Injectable } from '@angular/core';
import {
  CanActivate, Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivateChild,
  CanLoad, Route
} from '@angular/router';

import { UserService } from './user.service';
import { JwtService } from './jwt.service';
@Injectable()
export class AuthGuardService implements CanActivate, CanActivateChild, CanLoad {
  isAuthenticated = false;
  constructor(private userService: UserService, private router: Router,
    private jwtService: JwtService
  ) {
    this.userService.isAuthenticated.subscribe(
      (authenticated) => {
        this.isAuthenticated = authenticated;
      }
    );
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let url: string = state.url;

    return this.checkLogin(url);
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.canActivate(route, state);
  }

  canLoad(route: Route): boolean {
    let url = `/${route.path}`;
    return this.checkLogin(url);
  }

  checkLogin(url: string): boolean {
    let is_authenticated = this.jwtService.getData('is_authenticated');
    if ( is_authenticated === 'true') {
      return true;
    } else if (is_authenticated === 'false') {
      // Store the attempted URL for redirecting
      this.userService.redirectUrl = url;
      this.router.navigate(['/login']);
      return false;
    }

    // Store the attempted URL for redirecting
    // this.userService.redirectUrl = url;

    // Create a dummy session id
    // let sessionId = 123456789;

    // Set our navigation extras object
    // that contains our global query params and fragment
    // let navigationExtras: NavigationExtras = {
    //   queryParams: { 'session_id': sessionId },
    //   fragment: 'anchor'
    // };

    // Navigate to the login page with extras
    // this.router.navigate(['/login']);
    // this.authDailogService.confirm();
    // return false;
  }
}
