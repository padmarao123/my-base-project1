import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ApiService } from './api.service';
import { JwtService } from './jwt.service';
import { User } from '../models';
declare var jquery: any;
declare var $: any;
@Injectable()
export class UserService {
  private currentUserSubject = new BehaviorSubject<User>({
    username: 'User',
    photo_path: 'assets/icons/user_avatar.svg', type: 'default_user'
  });
  public currentUser = this.currentUserSubject.asObservable().distinctUntilChanged();

  private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
  public isAuthenticated = this.isAuthenticatedSubject.asObservable();
  redirectUrl: string;
  constructor(

    private apiService: ApiService,
    private http: Http,
    private jwtService: JwtService,

    private router: Router
  ) {
  }

  // Verify JWT in localstorage with server & load user's info.
  // This runs once on application startup.
  populate() {
    // If JWT detected, attempt to get & store user's info
    if (this.jwtService.getToken()) {
      this.setUserObjectWithToken('me')
        .subscribe(
        data => {
          this.setAuth(data);
          return data;
        },
        error => console.log(error));
    } else {
      // Remove any potential remnants of previous auth states
      //  this.redirectTpLogin();
    }
  }

  setAuth(user: User) {
    // Set current user data into observable
    this.currentUserSubject.next(user);
    // Set isAuthenticated to true
    this.isAuthenticatedSubject.next(true);
    this.jwtService.saveData('is_authenticated', 'true');
  }

  setToken(token: string) {
    // Save JWT sent from server in localstorage
    this.jwtService.saveToken(token);
  }

  purgeAuth() {
    // Remove JWT from localstorage
    this.jwtService.destroyToken();
    // Set current user to an empty object
    this.currentUserSubject.next({ username: 'User', photo_path: 'assets/icons/user_avatar.svg', type: 'default_user' });
    // Set auth status to false
    this.isAuthenticatedSubject.next(false);
     this.jwtService.saveData('is_authenticated', 'false');
     $.toast({
      heading: 'Session expired',
      text: ' You are logged out',
      icon: 'warning',
      loader: false, 
      bgColor: '#E65100',
      textColor: '#ffff',
      hideAfter: 10000,        // Change it to false to disable loader
      position: 'top-right'
    });
      this.router.navigateByUrl('/login');

  }

  attemptAuth(route, credentials): Observable<User> {
    return this.apiService.post(route, credentials)
      .map(
      data => {
        this.setToken(data.token);
        return data.token;
      }
      );
  }

  setUserObjectWithToken(route): Observable<User> {
    return this.apiService.get(route)
      .map(
      data => {
        return data;
      }
      );
  }

  getCurrentUser(): User {
    return this.currentUserSubject.value;
  }

  update(route, form_data): Observable<User> {
    return this.apiService
      .post(route, form_data)
      .map(data => {
        this.currentUserSubject.next(data.user);
        return data;
      });
  }

  // updateContact(route, form_data): Observable<User> {
  //   return this.apiService
  //     .post(route, form_data)
  //     .map(data => {
  //       this.currentUserSubject.next(data.user);
  //       return data;
  //     });
  // }


  post(route, form_data) {
    return this.apiService.post(route, form_data)
      .map(
      data => {
        return data;
      }
      );
  }

  getWithData(route, req_data) {
    return this.apiService.getWithData(route, req_data)
      .map(
      data => {
        return data;
      }
      );
  }

  get(route) {
    return this.apiService.get(route)
      .map(
      data => {
        return data;
      });
  }

  redirectTpLogin(){
  this.purgeAuth();
  }


}
