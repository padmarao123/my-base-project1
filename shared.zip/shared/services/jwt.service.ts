import { Injectable } from '@angular/core';

@Injectable()
export class JwtService {

  getToken(): String {
    return window.localStorage['jwtToken'];
  }

  saveToken(token: String) {
    window.localStorage['jwtToken'] = token;
  }

  destroyToken() {
    window.localStorage.removeItem('jwtToken');
  }

  getData(key): String {
    return window.localStorage[key];
  }

  saveData(key, value) {
    window.localStorage[key] = value;

  }

  destroyData(key) {
    window.localStorage.removeItem(key);
  }

}
