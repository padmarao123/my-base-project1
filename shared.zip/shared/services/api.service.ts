import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { environment } from '../../../environments/environment';
import { Headers, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { JwtService } from './jwt.service';
import { LoaderService } from './loader.services';
declare var jquery: any;
declare var $: any;
@Injectable()
export class ApiService {
  isToastShown = true;

  public token_expired = new BehaviorSubject({});
  constructor(
    private http: Http,
    private router: Router,
    private jwtService: JwtService,
     private loaderService: LoaderService,
  ) { }

  private setHeaders(): Headers {
    let headersConfig = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-Referrer': window.location.pathname,
      'X-Source': 'web',
      'X-Version': environment.version
    };

    if (this.jwtService.getToken()) {
      headersConfig['Authorization'] = `${this.jwtService.getToken()}`;
    }
    return new Headers(headersConfig);
  }

  // private formatErrors(error: Response | any) {
  //   if (error.headers.has('authorization')) {
  //     let token = error.headers.get('authorization');
  //     this.jwtService.saveToken(token);
  //   }
  //   let errData = { status: error.status, error: error.json() };
  //   return Observable.throw(errData);
  // }

  get(route): Observable<any> {
    var errData;
    this.showLoading();
    
    return this.http.get(environment.apiUrl + route, {
      headers: this.setHeaders()
    }).catch((error: Response | any) => {
      this.hideLoading();
      if (error.headers.has('authorization')) {
        this.jwtService.saveToken(error.headers.get('authorization'));
      }

      errData = { 'status': error.status, 'error': error.json() };
      console.log(errData);
     
      if (errData.error.error && errData.status == 401 && errData.error.authorization == 'access_denied') {
        
        $.toast({
          heading: 'Access denied ',
          text: errData.error.message,
          icon: 'warning',
          bgColor: '#E65100',
          textColor: '#ffff',
          loader: false, 
          hideAfter: 10000,        // Change it to false to disable loader
          position: 'top-right',
          
        });
        return Observable.throw(errData);

      }
      if (errData.error.error && errData.status == 401  ) {
        $.toast({
          heading: 'Access denied ',
          text: errData.error.message,
          icon: 'warning',
          loader: false, 
          bgColor: '#E65100',
          textColor: '#ffff',
          hideAfter: 10000,        // Change it to false to disable loader
          position: 'top-right'
        });
        this.token_expired.next(errData);
        return Observable.throw(errData);

      }
      if (errData.error.message === 'Token has expired' ) {
        this.isToastShown = false;
        // let snackBarRef = this.alertService.alert(errData.error.message, 'close', 3000);
        // snackBarRef.afterDismissed().subscribe(() => {
        //   this.isToastShown = true;
        // });
        this.token_expired.next(errData);
        return Observable.throw(errData);
      }

      if (errData.error.error  && errData.status == 401 && errData.error.message != 'Token has expired') {
        $.toast({
          heading: 'Authentication',
          text: errData.error.message,
          icon: 'warning',
          loader: false, 
          bgColor: '#E65100',
          textColor: '#ffff',
          hideAfter: 10000,        // Change it to false to disable loader
          position: 'top-right'
        });        return Observable.throw(errData);
      }
      
     
      if (errData.status === 500) {
        $.toast({
          heading: 'Server problem',
          text: errData.error.message,
          icon: 'warning',
          loader: false, 
          bgColor: '#E65100',
          textColor: '#ffff',
          hideAfter: 10000,        // Change it to false to disable loader
          position: 'top-right'
        });
        return Observable.throw(errData);
      }
    
    })
      .map((res: Response) => {
       
        if (res.headers.has('authorization')) {
          let token = res.headers.get('authorization');
          this.jwtService.saveToken(token);
        }
        this.hideLoading();
        return res.json();
        
      });
  }
  getWithData(route, data): Observable<any> {
    var errData;
    this.showLoading();
    let query_string = this.serialize(data);
    return this.http.get(environment.apiUrl + route + '?' + query_string, {
      headers: this.setHeaders()

    })
      .catch((error: Response | any) => {
        this.hideLoading(); 
        if (error.headers.has('authorization')) {
          this.jwtService.saveToken(error.headers.get('authorization'));
        }

        errData = { 'status': error.status, 'error': error.json() };
        if (errData.status === 401 && errData.error.authorization == 'access_denied') {
          
          $.toast({
            heading: 'Access denied ',
            text: errData.error.message,
            icon: 'warning',
            loader: false, 
            bgColor: '#E65100',
            textColor: '#ffff',
            hideAfter: 10000,         // Change it to false to disable loader
            position: 'top-right'
          });
          return Observable.throw(errData);
  
        }
        if (errData.error.error && errData.status == 401  ) {
          $.toast({
            heading: 'Access denied ',
            text: errData.error.message,
            icon: 'warning',
            loader: false, 
            bgColor: '#E65100',
            textColor: '#ffff',
            hideAfter: 10000,        // Change it to false to disable loader
            position: 'top-right'
          });
          this.token_expired.next(errData);
          return Observable.throw(errData);
  
        }
        if (errData.error.key === 'token_expired' && this.isToastShown) {
          this.isToastShown = false;
          // snackBarRef.afterDismissed().subscribe(() => {
          // this.isToastShown = true;
          // });
          this.token_expired.next(errData);
          return Observable.throw(errData);
          }
          
          

        if (errData.status === 401 && errData.error.key !== 'token_expired') {

          $.toast({
            heading: 'Server problem',
            text: errData.error.message,
            icon: 'warning',
            loader: false, 
            bgColor: '#E65100',
            textColor: '#ffff',
            hideAfter: 10000,        // Change it to false to disable loader
            position: 'top-right'
          });
         
        }
       
         

        if (errData.error.error && errData.status == 422) {
          var messages = errData.error.messages;
          if (messages) {
            var alert_content = "";
           
            alert_content += "<ul>";
            for (var key in messages) {
              if (messages.hasOwnProperty(key)) {
                alert_content += "<li>"+messages[key][0] + "</li>"
              }
            }
            alert_content += "</ul>";
            $.toast({
              heading: 'Check the following validation errors :-',
              text: alert_content,
              icon: 'warning',
              loader: false, 
              bgColor: '#E65100',
              textColor: '#ffff',
              hideAfter: 10000,        // Change it to false to disable loader
              position: 'top-right'
            });
    
          }
          return Observable.throw(errData);
        }
        if (errData.status == 500) {
          $.toast({
            heading: 'Server problem',
            text: errData.error.message,
            icon: 'info',
            loader: false, 
            // bgColor: '#E65100',
            // textColor: '#ffff',
            hideAfter: 10000,        // Change it to false to disable loader
            position: 'top-right'
          });
          return Observable.throw(errData);
        }
       
      })
      .map((res: Response) => {
        
        if (res.headers.has('authorization')) {
          let token = res.headers.get('authorization');
          this.jwtService.saveToken(token);
        }
        this.hideLoading();
        return res.json();
      });
  }
  serialize(obj) {
    let str = [];
    for (let p in obj) {
      if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
      }
    }
    return str.join('&');
  }


  post(path: string, body: Object = {}): Observable<any> {
    var errData;
    this.showLoading();
    return this.http.post(
      `${environment.apiUrl}${path}`,
      JSON.stringify(body),
      { headers: this.setHeaders() }
    )
      .catch((error: Response | any) => {
        this.hideLoading();
        if (error.headers.has('authorization')) {
          this.jwtService.saveToken(error.headers.get('authorization'));
        }
        errData = { 'status': error.status, 'error': error.json() };
        if (errData.error.error && errData.status === 401 && errData.error.authorization === 'access_denied' ) {
          $.toast({
            heading: 'Access denied ',
            text: errData.error.message,
            icon: 'error',
            loader: false, 
            hideAfter: 7000,        // Change it to false to disable loader
            position: 'top-right'
          });
          return Observable.throw(errData);
  
        }
        if (errData.error.error && errData.status === 401  ) {
          $.toast({
            heading: 'Access denied ',
            text: errData.error.message,
            icon: 'error',
            loader: false, 
            hideAfter: 7000,        // Change it to false to disable loader
            position: 'top-right'
          });
          this.token_expired.next(errData);
          return Observable.throw(errData);
  
        }
        if (errData.error.error && errData.status == 422) {
          var messages = errData.error.messages;
          if (messages) {
            var alert_content = "";
          
            alert_content += "<ul>";
            for (var key in messages) {
              if (messages.hasOwnProperty(key)) {
                alert_content += "<li>"+messages[key][0] + "</li>"
              }
            }
            alert_content += "</ul>";
            $.toast({
              heading: 'Check the following validation errors :-',
              text: alert_content,
              icon: 'info',
              loader: false, 
              
              hideAfter: 10000,        // Change it to false to disable loader
              position: 'top-right'
            });
    
          }
          return Observable.throw(errData);
        }
        if (errData.error.message === 'Token has expired' && this.isToastShown) {
          this.isToastShown = false;
          $.toast({
            heading: 'Access denied ',
            text: errData.error.message,
            icon: 'warning',
            loader: false, 
            bgColor: '#E65100',
            textColor: '#ffff',
            hideAfter: 10000,        // Change it to false to disable loader
            position: 'top-right'
          });
          this.token_expired.next(errData);
        }
        if (errData.status === 500) {
          $.toast({
            heading: 'Server problem',
            text: errData.error.message,
            icon: 'warning',
            loader: false, 
            bgColor: '#E65100',
            textColor: '#ffff',
            hideAfter: 10000,        // Change it to false to disable loader
            position: 'top-right'
          });
          return Observable.throw(errData);
        }
        return Observable.throw(errData);
      })
      .map((res: Response) => {
       
        if (res.headers.has('authorization')) {
          let token = res.headers.get('authorization');
          this.jwtService.saveToken(token);
        }
        this.hideLoading();
        return res.json();
      });
  }


  showLoading() {
    this.loaderService.display(true);
  }
  hideLoading() {
    this.loaderService.display(false);
  }
  // redirectTpLogin(){
  //   this.userService.purgeAuth();
  //   this.router.navigateByUrl('/login');
  //   }
}
