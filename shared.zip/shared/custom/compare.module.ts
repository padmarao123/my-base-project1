import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompareTo } from './compare-to.directive';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [CompareTo],
  exports: [
    CompareTo
  ]
})
export class CompareModule { }
